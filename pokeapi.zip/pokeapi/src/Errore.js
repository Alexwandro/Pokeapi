import React from 'react'
import './Errore.css'

const Errore = () => {
	return (
		<div id='container'>
			<div>Non è la pokeball che stavi cercando</div>
			<img src='https://www.kindpng.com/picc/m/74-743336_global-link-question-question-mark-unknown-pokemon-hd.png' alt='???'></img>
		</div>
	)
}

export default Errore