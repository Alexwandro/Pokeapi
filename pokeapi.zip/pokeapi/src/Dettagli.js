import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { BrowserRouter,Route,Routes,useNavigate } from 'react-router-dom'
import './Dettagli.css'

const Dettagli = () => {
	let indietro = useNavigate()
	// Ottiene il nome del pokemon dall'URL
	const { name } = useParams()
	// State per i dati del pokemon
	const [pokemon, setPokemon] = useState(null)
	
	//Fetch del pokemon richiesto
	useEffect(() => {
		fetch(`https://pokeapi.co/api/v2/pokemon/${name}`)
		.then((testo)=>testo.json())
		.then((infoJson)=>{
			setPokemon(infoJson)
		})
	}, [])

	// Mostra un messaggio di caricamento mentre fetch è in corso
	if (!pokemon) {
		return <div>Caricamento...</div>
	}

	// Renderizza i dati del pokemon
	return (
		<div>
			<button onClick={() => indietro(-1)}>Back</button> 
			<h1>{pokemon.name}</h1>
			<div>Forma normale:</div>
			<img alt='immagine.pokemon' src={pokemon.sprites.front_default}></img>
			<div>Forma shiny:</div>
			<img alt='immagine.pokemon' src={pokemon.sprites.front_shiny}></img>
			<div>Altezza: {pokemon.height} (dm)</div>
			<div>Peso: {pokemon.weight} (kg)</div>
			<div>Tipo: {pokemon.types.map(type => type.type.name).join(', ')}</div>
			<h2>Statistiche:</h2>
			{pokemon.stats.map((stat, index) => (
				<div key={index}>
					{stat.stat.name}: {stat.base_stat}
				</div>
			))}
		</div>
	)
}

export default Dettagli